            </div>
        </div>
        
        <div class="footer text-center mb-4">
            <div class="server-info">
                <p>
                    PHP Version: <?php echo phpversion(); ?> | 
                    Server Software: <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?>
                </p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
